# TV Launcher

A simple Google TV-style home screen that shows **only TV apps** (apps that declare the
`LEANBACK_LAUNCHER` category). Phone-only apps never appear.

- Big banner cards with a focus highlight, remote/D-pad friendly
- Clock and date, Settings shortcut
- Long-press an app to open its info page (uninstall, clear data)
- List refreshes automatically when apps are installed or removed
- Back never exits the launcher

## Get the APK (no Android Studio needed)

1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab, then run **Build APK** (it also runs on every push).
3. When it finishes, open the run and download the **tv-launcher-apk** artifact. Unzip it to get `app-debug.apk`.

Or open the folder in Android Studio and choose Build > Build APK(s).

## Install on the TV

1. On the TV, enable Developer options and ADB/USB debugging (Settings > System > About, tap the build number 7 times).
2. From a computer on the same network:
   ```
   adb connect <tv-ip>:5555
   adb install app-debug.apk
   ```
   (Or sideload with an app like "Send Files to TV".)

## Make it the default Home screen

Google TV normally keeps its own launcher. After installing, run:

```
adb shell cmd package set-home-activity com.example.tvlauncher/.MainActivity
```

If the TV ignores it, open the app from your apps list instead. Some Google TV builds
don't allow replacing the stock launcher at all.
