package com.example.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onOpen: (TvApp) -> Unit,
    private val onInfo: (TvApp) -> Unit,
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<TvApp> = emptyList()

    fun submit(list: List<TvApp>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.image)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        val density = holder.itemView.resources.displayMetrics.density

        val banner = app.banner
        if (banner != null) {
            holder.image.scaleType = ImageView.ScaleType.CENTER_CROP
            holder.image.setPadding(0, 0, 0, 0)
            holder.image.setImageDrawable(banner)
        } else {
            // No banner supplied by the app: show its icon centred on the card
            val pad = (36 * density).toInt()
            holder.image.scaleType = ImageView.ScaleType.CENTER_INSIDE
            holder.image.setPadding(pad, pad, pad, pad)
            holder.image.setImageDrawable(app.icon)
        }
        holder.label.text = app.label

        holder.itemView.setOnClickListener { onOpen(app) }
        holder.itemView.setOnLongClickListener { onInfo(app); true }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) 1.08f else 1f
            v.animate().scaleX(scale).scaleY(scale).setDuration(140).start()
            v.translationZ = if (hasFocus) 8 * density else 0f
            holder.label.alpha = if (hasFocus) 1f else 0.65f
        }
        holder.label.alpha = 0.65f
    }
}
