package com.example.tvlauncher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/**
 * A minimal Google TV-style home screen that lists ONLY apps built for TV
 * (those declaring the LEANBACK_LAUNCHER category).
 */
class MainActivity : Activity() {

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private val adapter = AppAdapter(onOpen = ::launch, onInfo = ::showAppInfo)
    private val executor = Executors.newSingleThreadExecutor()
    private var firstLoad = true

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        list.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        list.adapter = adapter

        findViewById<View>(R.id.settings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pressing Home while already on the launcher: jump back to the first app
        if (intent.hasCategory(Intent.CATEGORY_HOME)) focusFirst()
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        executor.shutdown()
        super.onDestroy()
    }

    // A launcher should never exit on Back
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean =
        if (keyCode == KeyEvent.KEYCODE_BACK) true else super.onKeyDown(keyCode, event)

    private fun loadApps() {
        executor.execute {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val ai = ri.activityInfo
                    TvApp(
                        label = ri.loadLabel(pm).toString(),
                        component = ComponentName(ai.packageName, ai.name),
                        banner = ai.loadBanner(pm) ?: ai.applicationInfo.loadBanner(pm),
                        icon = ri.loadIcon(pm),
                    )
                }
                .sortedBy { it.label.lowercase() }

            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                adapter.submit(apps)
                empty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
                if (firstLoad) {
                    firstLoad = false
                    focusFirst()
                }
            }
        }
    }

    private fun focusFirst() {
        list.scrollToPosition(0)
        list.post { list.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    private fun launch(app: TvApp) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }

    // Long-press an app to open its info page (clear data, uninstall, etc.)
    private fun showAppInfo(app: TvApp) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${app.component.packageName}"),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }
}
