package com.example.tvlauncher

import android.content.ComponentName
import android.graphics.drawable.Drawable

data class TvApp(
    val label: String,
    val component: ComponentName,
    val banner: Drawable?,
    val icon: Drawable,
)
